# Internee.pk Introduction Video - Task 03

![Thumbnail](docs/thumbnail.png)

## About this task
A short introduction video for fellow internees at **Internee.pk**, to connect, collaborate and build a strong community during the internship.

## Video
- Files in this repo: [`video/intro_video_with_voice.mp4`](video/intro_video_with_voice.mp4) (computer-generated voiceover) and [`video/intro_video_simple.mp4`](video/intro_video_simple.mp4) (silent version)
- LinkedIn post: PASTE-YOUR-LINKEDIN-POST-LINK-HERE
- (Optional) Google Drive / YouTube link: PASTE-VIDEO-LINK-HERE

## About me
| | |
|---|---|
| **Full name** | Subhan Ullah |
| **Preferred nickname** | [your nickname] |
| **Major** | Computer Engineering |
| **University** | COMSATS University Islamabad, Abbottabad Campus |
| **Current year** | 7th semester (expected graduation 2027) |
| **From** | [your city/area] |

## Tech interests
- Web development
- Mobile app development (Flutter & Firebase)
- [add your third interest, e.g. AI / data science / cyber security]

## Internship projects
- **Task 01:** LMS Learning App (Flutter, Firebase, REST APIs): PASTE-TASK-01-REPO-LINK
- **Task 02:** Feedback and Review App (Flutter, Firebase): PASTE-TASK-02-REPO-LINK

## Goals for this internship
- [e.g. Build real-world web and mobile apps]
- [e.g. Learn from fellow internees and collaborate on projects]

## Slides
![Slide 1](docs/slides/slide_1.png)
![Slide 2](docs/slides/slide_2.png)
![Slide 3](docs/slides/slide_3.png)
![Slide 4](docs/slides/slide_4.png)

## Video script
See [SCRIPT.md](SCRIPT.md).

## Connect
LinkedIn: PASTE-YOUR-LINKEDIN-PROFILE-LINK-HERE
