# Introduction Video Script (about 60-75 seconds)

Assalamualaikum and hello everyone! My full name is **Subhan Ullah**, and you can call me **[your nickname]**.

I'm a seventh-semester **Computer Engineering** student at **COMSATS University Islamabad, Abbottabad Campus**, and I'm expected to graduate in **2027**.

I'm from **[your city/area]**.

I'm passionate about **web development** and **mobile app development**. During this internship I built two Flutter and Firebase projects: an **LMS Learning App** and a **Feedback and Review App**. I'm also interested in **[third interest]**.

Outside of tech, I enjoy **[your hobby]**.

In this internship I want to improve my skills in **[your goal]**, learn from all of you, and collaborate on projects.

Thank you for watching. Let's learn and grow together!
